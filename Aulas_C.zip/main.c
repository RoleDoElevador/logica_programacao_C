#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main (void){

int escolha_do_usuario, contador_de_disparos = 0, acertos = 0;
float velocidade_inicial, angulo_de_inclinacao,            distancia_do_alvo, tamanho_do_alvo;
float grau_em_radiano, altura_maxima, tempo_trajeto, alcance_horizontal;
float total_alcances_horizontais = 0.0, media_dos_alcances_horizontais, maior_altura =0.0, porcentagem_dos_acertos;
int vetor_resumo [100], i;


printf("\n============= INTEGRANTES DO GRUPO ==============\n");
printf("\nJoao Vitor Gomes Alves\t\t\t\tRA: 21473930");
printf("\nMiguel Alexandre Barros Ferreira\tRA: 21066296");
printf("\nStefanie Britez Souza\t\t\t\tRA: 21424255\n");
printf("------------------------------------------------");

do {

  printf("\n\nMENU PRINCIPAL:\n");

  printf("\n1.) Simular Disparo;");
  printf("\n2.) Mostrar Estatisticas;");
  printf("\n3.) Mostrar Resumos de Todos os Disparos Realizados;");
  printf("\n4.) Sair.");

  printf("\n\nEscolha uma opcao: ");
  scanf("%d", &escolha_do_usuario);


switch(escolha_do_usuario){
case 1:

  do{
    printf("\nDigite a Velocidade Incial: ");
    scanf("%f", &velocidade_inicial);} 
  while (velocidade_inicial <= 0);

  do{
    printf("Digite o Angulo de Inclinacao do Canhao (em graus): ");
    scanf("%f", &angulo_de_inclinacao);} 
  while (angulo_de_inclinacao <= 0 || angulo_de_inclinacao >= 90);

  do{
    printf("Digite a Distancia do Alvo: ");
    scanf("%f", &distancia_do_alvo);} 
  while (distancia_do_alvo <= 0);

  do{
    printf("Digite o Tamanho do Alvo: ");
    scanf("%f", &tamanho_do_alvo);}
  while (tamanho_do_alvo < 20 || tamanho_do_alvo > 50);

  grau_em_radiano = angulo_de_inclinacao*(3.14/180);

  altura_maxima = (((velocidade_inicial*velocidade_inicial)*sin(grau_em_radiano))/(2*9.81));

  if (altura_maxima >= maior_altura){
  maior_altura = altura_maxima;}

  tempo_trajeto = (2.00*velocidade_inicial)*(sin(grau_em_radiano))/9.81;

  alcance_horizontal = (2.00*(velocidade_inicial*velocidade_inicial))*((cos(grau_em_radiano)*sin(grau_em_radiano))/9.81);

  total_alcances_horizontais += alcance_horizontal;


  printf("\nAlcance Horizontal: %.2f", alcance_horizontal);
  printf("\nTempo Trajeto: %.2f", tempo_trajeto);
  printf("\nAltura Maxima: %.2f", altura_maxima);

  if (alcance_horizontal > distancia_do_alvo && alcance_horizontal < distancia_do_alvo+tamanho_do_alvo){
  printf("\nO Disparo Acertou o Alvo!");
  acertos++;
  vetor_resumo[i++] = 1;}

  else if (alcance_horizontal < distancia_do_alvo+tamanho_do_alvo ){
  printf("\nO Disparo Caiu Antes do Alvo");
  vetor_resumo[i++] = 0;}

  else if (alcance_horizontal > distancia_do_alvo+tamanho_do_alvo ){
  printf("\nO Disparo caiu Depois do Alvo");
  vetor_resumo[i++] = 0;}

  contador_de_disparos++;  
  break;

case 2:

  if ( contador_de_disparos == 0 ){
  printf("\nAinda não foi feito nenhum Disparo!");}

  media_dos_alcances_horizontais = total_alcances_horizontais/contador_de_disparos;

  porcentagem_dos_acertos = ((1.0*acertos)/contador_de_disparos)*100.0;

  printf("\nMedia dos Alcances Horizontais: %.2f", media_dos_alcances_horizontais);
  printf("\nMaior Altura Atingida %.2f", maior_altura);
  printf("\nPorcentagem que Atingiu o Alvo: %.2f%%", porcentagem_dos_acertos);

  break;

case 3:

  if ( contador_de_disparos == 0 ){
    printf("\nAinda não foi feito nenhum Disparo!");}

  else
    for (int i = 0; i < contador_de_disparos; i++){
      if (vetor_resumo[i] == 1){
        printf ("\nO disparo %d atingiu o alvo\n", i+1);}

      else if (vetor_resumo[i] == 0){
        printf ("\nO disparo %d não atingiu o alvo\n", i+1);}}

  break;

case 4:
  printf("\nAdeus!");
  break;

default:
  printf("\nOpcao Invalida!");
  break;}

}while (escolha_do_usuario != 4);

  }